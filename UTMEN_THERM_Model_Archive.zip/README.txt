arXiv Submission Kit for:
Unified Tension-Mediated Exchange Networks: Triple-Scale Resonance in Tensional Harmonic Geometry

Author: Matthew S. Le1
Email: mle1ravens@gmail.com

Upload all contents of this folder to https://arxiv.org/ under physics.gen-ph or gr-qc.
Ensure figures display properly on preview. PDF will compile automatically from main.tex.
